export interface Nota{
    id?:any,
    titulo: string,
    texto: string,
    fecha?: any,
    coordenadas?:any,
    imagen?:any
}