import { Component, OnInit } from '@angular/core';
import { GooglePlus } from '@ionic-native/google-plus/ngx';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  constructor(private google:GooglePlus) { }

  ngOnInit() {
  }

  public login(){
    this.google.login({}).then(respuesta=>{
      console.log(respuesta);
    } ).catch(err=>{
      console.log(err);
      
    })
  }
}
