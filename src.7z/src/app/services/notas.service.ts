import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection } from 'angularfire2/firestore';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Nota } from '../model/nota';

@Injectable({
  providedIn: 'root'
})
export class NotasService {

  private myCollection:AngularFirestoreCollection<any>;


  constructor(private fire:AngularFirestore) {
    this.myCollection =  fire.collection<any>(environment.notasCollection);
   }


   public agregaNota(notaNueva:Nota):Promise<any>{
     return this.myCollection.add(notaNueva);
   }

   public leeNotas():Observable<firebase.firestore.QuerySnapshot<firebase.firestore.DocumentData>>{
     return this.myCollection.get();
   }

   public leeNota(id:any):Observable<any>{
     return this.myCollection.doc(id).get();
   }

   public actualizaNota(id:any, notaNueva:Nota):Promise<void>{
     return this.myCollection.doc(id).set(notaNueva);
   }

   public borraNota(id:any):Promise<void>{
     return this.myCollection.doc(id).delete();
   }

   leeNotaPorCriterio(){//buscar por campo

   }
}
