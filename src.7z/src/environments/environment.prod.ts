export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyC6Sh6KuJV2Cgu80o-JT-bpYGffwllHu_I",
    authDomain: "notea-8d288.firebaseapp.com",
    databaseURL: "https://notea-8d288.firebaseio.com",
    projectId: "notea-8d288",
    storageBucket: "notea-8d288.appspot.com",
    messagingSenderId: "855076205522",
    appId: "1:855076205522:web:aa01ddefee5416af068e0b"
  },
  notasCollection: 'Notas'
};
